define([], function() {
    return undefined;
});